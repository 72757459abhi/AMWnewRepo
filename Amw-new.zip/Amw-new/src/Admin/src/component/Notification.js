import React from "react";
import { Modal, Button } from "react-bootstrap";
import "../../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";

const Notification = (props)=>{
    return(
        <>
        <Modal
      show={props.showModal}
      onHide={props.setShowModal(false)}
      aria-labelledby="ModalHeader"
      centered
      size="xl"
      className="ModalUserCreate"
    >
      <Modal.Header closeButton onClick={props.setShowModal(false)}>

      </Modal.Header>
      <Modal.Body>
        <button onClick={()=>{props.logoutFun()}}>Yes</button>
        <button onClick={()=>{props.setShowModal(false)}}>No</button>
      </Modal.Body>


      </Modal>
        </>
    )
}
export default Notification;